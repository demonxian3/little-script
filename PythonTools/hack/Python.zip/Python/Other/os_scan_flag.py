#import Flag1
import nmap
import optparse



#def Flag5(host):
def osscan(host):
	scanner = nmap.PortScanner()
	#scanner = Flag1.PortScanner()

	results = scanner.scan(hosts=host, arguments='-O')
	#res = Flag2['scan'].values()
	res = result['scan'].values()
	print res[Flag3]['osmatch'][Flag4]['name']



def main():  
	parser = optparse.OptionParser('usage%prog '+'-H <target host>')  
	parser.add_option('-H', dest='tgtHost', type='string', help='specify target host')  
	(options, args) = parser.parse_args()  
	host = options.tgtHost  
	if host == None:  
		print parser.usage  
		exit(Flag4)
	osscan(host)
	
if __name__ == '__main__':
	main()
