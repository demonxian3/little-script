from F1.all import *
import F2
from F3 import *
#Flag1=F1.F2.F3
#Flag1=scapy.optparse.threading


def F4(packet):
	try:
		reply = srp1(packet,timeout = 1,verbose = 0,iface = 'eth0')
		print 'IP:' + reply.F5 + '          MAC:' + reply.F6

	except:
		pass

#Flag2=F4.F5.F6
#sweep.psrc.hwsrc
	
def main():  
	parser = optparse.OptionParser('usage%prog '+'-H <target host segment/eg:(192.168.1.)>')  
	F7.add_option('-H', dest='tgtHost', type='string', help='specify target host segment/eg:(192.168.1.)')  
	(options, args) = parser.parse_args()  
	host = F8.tgtHost
	if F9 == None:   
		print parser.usage  
		exit(0)
	#Flag3=F7.F8.F9
	eth = F10()
	eth.F11 = 'ff:ff:ff:ff:ff:ff'
	eth.F12 = 0x0806
	arp = ARP()
	#Flag4=F10.F11.F12
	for n in range(1,254):
		arp.F13 = host + str(n)
		F14 = eth/arp
		t = Thread(target = sweep, args = (packet))
		F15.start()
		
#Flag3=parser.options.host
#Flag4=Ether.dst.type

	
if __name__ == '__main__':
	main()

#Flag5=F13.F14.F15
#Flag5=pdst.packet.t
