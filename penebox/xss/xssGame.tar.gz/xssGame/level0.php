<h1 style="color:#fff;text-align:center;text-shadow: 0 0 20px red;font-size:60px" >XSS游戏</h1>
<hr style="color:pink;width:900px;">
<pre style="color:red;text-align:center">
    想尽办法通过提交参数注入代码使得页面成功弹窗，不允许直接在连接上直接输入：
    javascript:alert();
    也最好不要跳关比如直接输入level7.php这样，不要欺骗自己，每一关都有不同的xss防御手段

    点击下面的图片开始游戏
</pre>
<hr style="color:pink;width:900px;">
<a href="level1.php?name=Demon"><img width="100%" height="40%" src="img/logo.jpg" style="cursor:pointer"></a>
<p style="color:#fff;font-size:30px;text-align:center;text-shadow: 0 0 20px green;"><b>written by demon</b></p>
<!-- 既然还没开始游戏你就打开源码来看了，那我就把PHP代码给你看吧，每一关的php代码名字为“关卡号.txt ”  -->
